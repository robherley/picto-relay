# ESP32 hardware evidence

Historical serial logs and experiment summaries from ESP32 development. These are
reference evidence, not runtime dependencies or current build instructions.
Packet captures recorded by the Raspberry Pi are in [../pi](../pi/README.md).
The Rust runtime retains its required regression fixtures in `tests/fixtures`.
