# Raspberry Pi capture archive

Packet captures from the Raspberry Pi use scenario-based names when their
contents have been verified. Timestamp-prefixed captures have a JSON sidecar with
the scenario, device roles, outcome, packet counts, and capture hash. A filename is
not treated as evidence on its own; use the sidecar and inspect the decompressed PCAP with Wireshark.

Captures are individually gzip-compressed. Each compressed file was decompressed
and SHA-256 checked against the original before the original was removed. Hashes
in historical sidecars describe the **decompressed** packet bytes. Extract a copy:

```sh
gzip -dc captures/pi/01-two-ds-baseline.pcap.gz > /tmp/two-ds.pcap
```

## Canonical captures

| Capture | What it proves |
|---|---|
| `01-two-ds-baseline.pcap.gz` | Baseline protocol exchange between two real Nintendo DS systems. |
| `1787193673345-real-ds-clean-join-baseline.pcap.gz` | Cold Room A host, second real DS joins, idles, then leaves without sending a message. |
| `1787275056402-virtual-client-outbound-dot-padded-final.pcap.gz` | Virtual AR9271 client joins a real DS host, initializes its profile, and delivers a dot; the host pads its short final rebroadcast fragment. This is the canonical outbound capture. |
| `1786660066567-joined-client-bitmap-validation.pcap.gz` | Controlled repeated drawing shapes from the real DS client that joined second. |
| `1786659145818-client-dot-matrix.pcap.gz` | Controlled real-client dot sequence with usable Nintendo traffic. |
| `20260821-sliding-window-hello-rendered-then-timeout.pcap.gz` | Diagnostic first sliding-window send: the real DS rendered HELLO, but Linux captured only 15 of 16 drawing-reply markers and the software queue timed out. Its sidecar documents the cumulative-cursor fix this motivated. |
| `20260821-cumulative-cursor-half-o-fragment-skip.pcap.gz` | Diagnostic cumulative-cursor session: an ACK-window race skips offset `0x0640`, visibly removing the lower half of the final `O` in `HELLO`. The sidecar records the exact offsets and notes the truncated final PCAP record. |
| `20260821-ack-window-retry-clean.pcap.gz` | Mixed verification: two complete consecutive one-band messages prove offset `0x0640` retransmission fixed the half-`O`; a later five-band message stalls at cursor 50, preserving the next sliding-ring defect. |
| `20260821-direct-return-ring.pcap.gz` | Canonical variable-height success: one session delivers 16-, 41-, 28-, 54-, and 67-reply messages. The last host rebroadcast is a complete 10,276-byte 256x80 drawing, proving more than four in-place ring wraps. |
| `20260823-software-host-ap-template.pcap.gz` | Canonical software-host management-plane success: ath9k advertises the custom Room A AP beacon, a real DS authenticates and associates into slot 1 eleven times, then leaves because the intentionally incomplete host sends no Nintendo CMD polls. |

## Supporting and negative captures

| Capture | Classification |
|---|---|
| `1787274121174-virtual-client-outbound-dot-pre-commit-partial.pcap.gz` | Supporting outbound success before the firmware commit barrier. Explicitly partial because it was copied while open and ends with a truncated PCAP record. |
| `1787274651933-virtual-client-auth-timeout-room-already-occupied.pcap.gz` | Negative authentication test. Despite its former `outbound-message-debug-1` name, it contains no association or drawing. |
| `identity-attempt.pcap.gz`, `identity-clean-attempt.pcap.gz`, `identity-offset-diagnostic.pcap.gz`, `inline-identity-stall.pcap.gz` | Virtual-client identity/profile handshake diagnostics. |
| `hidden-preload-control-stall.pcap.gz`, `no-leak-sequence-diagnostic.pcap.gz`, `prearmed-first-poll.pcap.gz`, `session-state-fix-2.pcap.gz`, `fresh-room-initialization-2.pcap.gz` | Firmware responder state and timing diagnostics. Names describe the experimental change under test, not a successful protocol milestone. |
| `active-idle-host-4d.pcap.gz` | Steady host/idle traffic diagnostic. |
| `20260821-known-good-three-band-control.pcap.gz` | Negative baseline: valid multi-band fragments stop at cursor 25/offset `0x0e60`. |
| `20260821-proactive-credit-return.pcap.gz` | Negative HTC-credit hypothesis test: a one-band control succeeds, but the three-band transfer still stops at cursor 25. |
| `20260821-in-place-message-ring-retry.pcap.gz` | Supporting intermediate: retained-slot byte refresh works, but refill uploads still consume TX descriptors and the transfer stalls. |
| `session-state-fix.pcap.gz` | Empty PCAP containing only the 24-byte global header; retain only as a record of the aborted run. |
| `1785458857956-client-one-pixel.pcap.gz`, `1786659123866-client-dot-matrix.pcap.gz` | Early captures whose sidecars show zero decoded Nintendo frames; superseded by later controlled captures. |
| `pictochat-ch1-20260730-185103.pcap.gz` | Original exploratory channel-1 capture; superseded by `01-two-ds-baseline.pcap.gz`. |
| `20260823-software-host-m1.pcap.gz` | Negative first hosting attempt: monitor-injected beacons were radiated, but the real DS ignored them and became a competing Room A host. Superseded by the AP-template capture. |
| `20260823-software-host-heartbeat-m1.pcap.gz` | Negative first heartbeat test: management association succeeds, but an invalid pre-initialization two-byte idle command produces 6,458 captured polls and zero client replies. This establishes that the host must begin with the `c34` roster exchange. |
| `20260824-software-host-c34-heartbeat-m2.pcap.gz` | Negative opening-roster diagnostic: the `c34` body is present, but its first transmission races the association response and no client data is returned. |
| `20260824-software-host-c34-delayed-m3.pcap.gz` | Negative timing diagnostic after adding the post-association delay: the first roster is admitted cleanly, but the measured command-to-ACK interval is about 1.00 ms rather than the real host's 1.248 ms and no client data is returned. |
| `20260824-software-host-c34-ack-compensated-m4.pcap.gz` | Negative deadline diagnostic: increasing the nominal userspace delay leaves the air ACK boundary at about 0.999 ms, proving the blocking receive path overrides that deadline. |
| `20260824-software-host-c34-echo-sync-m5.pcap.gz` | Negative receive-timeout diagnostic: scheduling from the ath9k transmit echo is logically correct, but the normal 20 ms receiver delays the first ACK by about 10 ms. This motivated the dedicated low-latency radio mode. |

Temporary files under `/private/tmp` are working snapshots and are not canonical.
The archive copy plus its sidecar is the labeled source of truth.


The `20260824-software-host-c34-{low-latency-real-ds-m7,echo-wait-m8}.analysis.json`
files summarize complete records from captures with truncated tails. They separate
injection requests from TX-status echoes, report the 2 Mbps request / 1 Mbps status
mismatch, and establish zero client data replies. Regenerate with
`scripts/summarize-host-capture.py`; see `docs/software-host.md` for corrected timing
interpretations. Historical manifests' `captured_host_polls` can count both copies.


## 2026-09-11 ESP32 reply timing

`20260911-{edca80,raw-iram,hot80,iram-map,iram160,final-radio}.rounds.json`
records DS poll/reply timing for successive private SDK queue/RAM experiments.
The original DS/ESP32-only PCAPs are retained locally. Correcting archive-specific
IRAM placement reduced median reply delay; the 160-byte trial still failed.
The final 80-byte firmware delivered six full-height drawings in 2.768–2.871 s.
See `captures/esp32/20260911-radio-timing.json` for per-run
times and the final firmware hash. The Pi adapter wlan1 was restored to managed
mode after the final capture; wlan0 was untouched.


## 2026-09-12 ESP32 120-byte validation

`20260912-prepared120.pcap.gz` and its `.rounds.json` sidecar capture the corrected
prepared-reply build using 120-byte fragments. The 45-second capture contains
17,696 packets with zero kernel drops and covers part of a nine-drawing run.
All nine deliveries completed in 1.842–1.887 s and the user confirmed correct DS
display. The complete server log and timings are in
`captures/esp32/20260912-prepared120*`. Pi wlan1 was restored
to managed/up afterwards; wlan0 was unchanged.


The `20260912-{stages115200,baud460800,baud921600}.pcap.gz` captures compare UART
rates while retaining 120-byte fragments and prepared radio replies. Packet
counts were 18,393 / 18,740 / 18,750, with zero kernel drops. The `.transfers.json`
sidecars use FCS-verified frames and direction-specific padded footers to group
first-to-last fragment spans; missing intermediate packets and omitted incomplete
endpoints must not be confused with failed DS delivery. These spans exclude
announcement/final-ACK and host USB processing. See the archived transfer summaries
and `captures/esp32/20260912-uart-latency.json`.
