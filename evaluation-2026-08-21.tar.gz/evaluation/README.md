# Evaluation (2026-08-20)

Independent evaluation of the Picto Relay protocol implementation against the
real-DS packet captures in [`captures/blueberry/`](../captures/blueberry/).

- [`findings.md`](findings.md) — the full report: verified-correct wire
  conventions, then ranked findings (P1–P3) covering the firmware's
  no-loss-recovery message transaction, the engine's capture-falsified delivery
  detection, reassembly collisions, state-machine/doc inconsistencies, and
  capture-fidelity artifacts.
- [`scripts/`](scripts/) — the standalone Python 3 analysis scripts (no external
  dependencies) that produced every number in the report. Run them from that
  directory with a capture filename, e.g.
  `python3 timing.py 01-two-ds-baseline.pcap`. Each script's role is tabulated
  in the report's "Method notes" section.
