# Project evaluation: pcap traces vs. protocol implementation

Date: 2026-08-20. Scope: every crate, the AR9271 firmware patch, the protocol
documentation, and the captures in `captures/blueberry/`. All capture numbers below
were re-derived independently from the pcap bytes (radiotap + 802.11 parsed from
scratch), not taken from the existing docs or sidecars.

## Summary

The wire model is in very good shape: every byte-level convention the codec
enforces (envelope length rules, the padded host-final exception, fragment
layouts, frame-number arithmetic, management frame shapes, even the
`duration = 1030 − 4 × payload` reply formula) matches the real-DS captures
exactly. The bugs are concentrated exactly where the report requested scrutiny —
**timing and message ordering**:

1. **(P1)** The firmware advances the outbound drawing transaction one fragment per
   targeted poll with no loss recovery. Measured round-failure rates (~1.4–1.5 %)
   predict roughly **1 in 5 outbound drawings silently loses a fragment** and times
   out. This is almost certainly the user-visible "sometimes my drawing never
   arrives" bug.
2. **(P1)** The engine's delivery detection (`ack.command_count == final fragment's
   MAC sequence`) is **falsified by the captures** (0/2349 and 3/1250 matches —
   chance level). It only works against the scripted loopback that was built to
   satisfy it.
3. **(P2)** Host-rebroadcast reassembly in the live backend cannot separate
   concurrent transfers (real DSs always use opaque id `00 00`), and a
   `ConflictingFragment` error tears down the entire radio session.
4. **(P2)** The Rust software state machine and the two protocol documents describe
   three different identity-exchange orderings; the real-client baseline agrees
   with `packet-shapes.md`, not with `pictochat-protocol.md`'s table, and the
   software (`experimental_profile`) path still contains the "session response
   preloaded but never selected" regression the docs describe as fixed.

Plus several smaller capture-fidelity and robustness issues detailed below.

---

## What the captures confirm (verified correct)

Checked against `1787193673345-real-ds-clean-join-baseline.pcap` (6,251 frames),
`01-two-ds-baseline.pcap` (13,388 frames), and
`1787275056402-virtual-client-outbound-dot-padded-final.pcap` (~162 k frames):

| Claim | Result |
|---|---|
| Host `declared_length == payload`, client `== payload + 2` | **0 violations** across both real-DS captures (every recognized envelope) |
| Padded host final (`0x9e56`, declared 16, physical 172, fn/trailer at physical end) | Byte-exact in the canonical capture: `dl=4 fin=1 off=2080 fn=43 tr=2`, 156 zero-pad bytes |
| `frame_number = start_frame + offset/160` | Holds for every observed transfer: client upload fn 3–16; host rebroadcasts fn 30–43 and fn 6–19; the 6,180-byte host message fn 20+ |
| Client reply MAC shape: data subtype 1, To-DS, PM bit, 2 Mbps | All 1,164 real-client replies match (plus 26 CF-Ack/no-data subtype-5 frames, see D-7) |
| `duration = 1030 − 4 × body_len` (`build_client_reply_frame`) | Exact for every real reply: (2 B, 1022), (24 B, 934), (100 B, 630), (108 B, 598) |
| Auth/assoc shapes: dur `0x00a2`, PM bit, caps `0x0021`, listen 1, rates `82 84`, 32-byte binary SSID = game_id ‖ stream_code | Byte-identical to the real client (which used the *current* beacon stream `0x033e` after it advanced from `0x033d` — the refresh-before-associate behavior is right) |
| AID `0xc001` → slot = low nibble | Confirmed |
| Beacon layout (custom_length at +0x12, type 1, caps `0x00c0`/`0x00c0`, 8-byte room payload) | Confirmed; interval 107 TU, `game_id = 0x00000000` for PictoChat |
| `client_time` 998 dominant, occasional 214 | Confirmed (998/214 only) |
| Host repeats application fragments across rounds with *fresh* MAC sequence numbers and no retry flag | Confirmed — MAC-sequence dedup alone cannot dedupe app-level repeats; the offset/frame-tolerant reassembler is the right design |
| Reassembler handles the canonical rebroadcast incl. duplicates and the padded final | Confirmed by walking the capture through the same rules |

`cargo test --workspace --locked`: all green (95 tests).

---

## P1 findings

### 1. Outbound transaction: one fragment per poll, no loss recovery

`firmware/patches/0001-picto-relay-slot-reply.patch`, `ath_tgt_picto_select_reply`,
`PICTO_STATE_STEADY` branch: every targeted poll unconditionally does
`picto_message_index++` and transmits the next template. Nothing consults the
host acknowledgement (`03:09:bf:00:00:03` frames are not even parsed by the
firmware), so a reply the host missed is *skipped forever* — the host's
reassembly keeps a permanent hole, never completes, never rebroadcasts, and the
API surfaces `DeliveryTimedOut` 8 s later.

Measured probability that this bites, from the failed-client-mask in host acks:

| Capture | Failed rounds / acks | Per-round loss |
|---|---|---:|
| `01-two-ds-baseline.pcap` | 72 / 4,648 | 1.55 % |
| canonical outbound (360 s session) | 1,167 / 81,133 | 1.44 % |

A 16-reply transaction completes cleanly with probability ≈ 0.9856¹⁶ ≈ **79 %**.
The canonical capture's transaction happened to hit a clean window (no failed
round between announcement and completion — verified), which is why the milestone
run succeeded; roughly one in five attempts will not.

The identity exchange does **not** have this bug — it is keyed to host packet IDs,
so duplicate polls re-select the same reply (and the docs proudly note this). The
message transaction needs the same property. Evidence that the real protocol
retransmits: `failed_client_mask` exists per round, the host visibly re-polls with
identical command payloads after failures, and real transfers show the same
fragment persisting across consecutive rounds.

**Fix direction:** advance `picto_message_index` only after observing the next
host command whose preceding round did not flag the slot (the firmware already
tracks `picto_completion_unreported`/`picto_last_tx_clean`); or watch the host ack
frames and re-queue the same template when `failed_client_mask & picto_client_mask`
was set. Note the message buffers are currently freed on TX completion
(`ath_tgt_tx_comp_normal` for `template >= PICTO_REPLY_MESSAGE_BASE`), so
retransmission also requires keeping the buffer until the round is confirmed.

### 2. Engine delivery detection contradicts the captures

`crates/picto-relay-engine/src/lib.rs:391` (`observe_ack`): a pending message is
declared Delivered when a host ack's `command_count` equals the MAC sequence
number of the message's final fragment. Tested against reality:

- clean baseline: `ack.command_count == preceding cmd's MAC seq` in **3 of 1,250** rounds;
- two-DS baseline: **0 of 2,349**;
- `command_count` deltas between consecutive acks are erratic (±dozens), it is not
  a frame counter that anything else echoes.

The correlation only holds inside the project's own loopback, because
`build_ack_frame` deliberately stuffs `command_count` into the MAC sequence field
and `Broker::loop_back_recorded_transmissions` synthesizes the ack from the final
fragment's sequence number. So the engine's Delivered/retry logic is
self-referential and would never fire (or fire wrongly) against real traffic.

Two additional defects in the same function:

- The match scans **all clients'** pending messages for any `final_sequence`
  equal — two clients whose 12-bit sequence counters collide (they all start at 0)
  can acknowledge each other's messages.
- Only acks with `failed_client_mask == 0` are considered; a round that failed for
  an *unrelated* slot suppresses the ack entirely.

**Fix direction:** the live backend's approach (confirm delivery by observing the
host rebroadcast of your own message) is the capture-supported one; the engine
should adopt it, or at minimum correlate per-source and stop treating
`command_count` as an echo of client sequence numbers.

---

## P2 findings

### 3. Live-backend reassembly: concurrent transfers collide, and a conflict kills the session

`crates/picto-relay-join/src/main.rs` (`receive_live_message`):

- The reassembly key is `(station, fragment.opaque_id)` where `station` is *our
  own constant MAC* — so every host-rebroadcast fragment lands in one bucket per
  opaque id. Real DS transfers use opaque id `00 00` in **every** captured
  transfer (both directions, both baselines). With three or more users, two
  concurrent rebroadcast transfers therefore share a single bucket:
  `align_transfer_start` wipes the partial each time the other transfer's
  offset-0 fragment arrives (`*partial = PartialMessage::default()`), so the two
  transfers alternately destroy each other and neither ever completes.
- Worse, if interleaved fragments ever land on the same offset with the same
  expected frame number but different bytes, `reassembler.push` returns
  `DecodeError::ConflictingFragment`, which `receive_live_message` propagates with
  `?` through `maintain_live_backend` — the whole radio session errors out, the
  broker reports `hardware_failed`, and the station drops off the room. A single
  corrupt-but-FCS-valid fragment can do this too.

The engine (`observe_data`) has the same collision by a different route: it keys
on `data.source`, but every rebroadcast fragment's source is the host MAC, which
is equally constant.

**Fix direction:** treat `ConflictingFragment` as "reset that partial and keep
going", never as a session-fatal error; and consider correlating transfers via
the `d0a` announcements (they precede each transfer and carry the byte count)
and/or disjoint frame-number windows, since the wire genuinely lacks a per-transfer
id in the fragment itself.

### 4. Three inconsistent identity-exchange orderings; software path still has the old deadlock

Ground truth from `1787193673345-real-ds-clean-join-baseline.pcap` (annotated):

```text
host 1c34            → client 8c34 aseq6   (session response)
host 1c34 ×2         → 00 80
host 1d0a            → client 8d0a          ← announcement answers d0a
host 1e30 subtype 0  → 00 80                ← host profile comes AFTER
host 1d0a            → 00 80
(next poll)          → client 8e30 subtype 0 (profile)
host 9e30 subtype 0  → 00 80
host 1c34            → client 8d0a aseq3    (completion)
… second pass, then steady
```

- `docs/pictochat-protocol.md`'s state-machine table says the client's initial
  `d0a` announcement is triggered by the **host `e30` subtype-0 profile**; the
  firmware (`PICTO_STATE_WAIT_INITIAL_HOST_PROFILE` requires `0x1e30` +
  `data[43]==0`) implements that. The real-client baseline shows the announcement
  answering the host's **`1d0a`**, before any `e30` arrives —
  `docs/packet-shapes.md`'s "Join identity exchange" sequence agrees with the
  capture. Both documents claim to describe the same baseline. The firmware order
  demonstrably works against a real host (the host repeats its openers), but the
  two documents contradict each other and one of them contradicts its own cited
  evidence.
- `initialization_reply` (Rust) has **no session state at all**: its default phase
  is `InitialHostProfile` and no branch ever emits `captured_session_response()`.
  In `--experimental-profile` (software-reply) mode the first `1c34` therefore
  gets an idle reply and the host repeats `c34` forever — precisely the historical
  bug `pictochat-protocol.md` describes as fixed ("Picto Relay originally had this
  response preloaded but never selected it"). Only the firmware path fixed it.
- In firmware-assist mode the same Rust function runs as a *shadow tracker* whose
  transitions must observe the exact same host frames the firmware saw. Monitor RX
  loss (present in the baseline — at least one host cmd before the client's
  profile reply is missing from the capture) desynchronizes it; then
  `profile_finalized()` never turns true, `LiveEvent::Ready` never fires, and
  queued API messages are never armed even though the firmware reached STEADY.
  The firmware knows its own state; exposing it (e.g., via the existing
  diagnostic channel) would be more robust than parallel inference.

---

## P3 findings

### 5. Virtual-client captures contain phantom frames and no real replies — undocumented

Two capture-fidelity artifacts (both verified byte-level):

- `LinuxMonitorRadio::transmit` writes every **injected** frame into the pcap
  (`crates/picto-relay-radio/src/lib.rs:295`), so all firmware arm frames appear
  with their private 2-byte markers still attached (`… c0b1/c1b1/…` tails,
  radiotap flags `0x02`, 1 Mbps).
- During a transaction, the one-shot message templates complete back through
  `ath_tgt_tx_comp_normal`, and the kernel's TX-status monitor reflection writes
  the **pre-firmware host-side skb** into the capture at poll cadence — again with
  markers, at the injection rate, not the on-air 2 Mbps. These masquerade as
  client replies (`dlen == wire_len` instead of `wire_len + 2`; a naive parser
  reads the marker bytes as frame numbers `0xB1Cx` ≈ 45505+).

Consequences: the true on-air replies (trimmed, marker-free) are **absent** from
every virtual-client capture; `PictoChatEnvelope::parse` rejects the loopback
copies as malformed; and the identity replies (whose buffers are retained, never
completed back) are entirely invisible. None of this is mentioned in
`captures/blueberry/README.md` or `protocol-evidence.md`, and claims like "the
capture contains the sixteen-frame drawing transaction" are actually satisfied by
loopback copies. Worth a paragraph in the captures README so future analysis (or
an LLM, or `picto-relay-listen`) doesn't chase phantom protocol violations.

Related: the firmware's diagnostic mirror rewrites the **host poll's MAC
sequence/fragment fields** in captured copies (queue-delay ≪ 4 | status). That is
by design, but it also means (a) virtual captures' host-cmd sequence numbers are
meaningless, and (b) `Engine::remember_sequence` would treat almost all live host
polls as duplicates (seq pinned to the 15–18 µs queue-delay values) if the engine
were ever fed this radio path or a replay of these captures.

### 6. Engine rejects idle traffic, contradicting the documented decode order

`docs/packet-shapes.md` rule 7: "Treat payloads shorter than six bytes as
idle/status traffic, not envelopes." `Engine::observe_data` instead does
`PictoChatEnvelope::parse(...)?` — every real idle reply (`00 80`, `00 00`,
empty) and every 6-byte idle host command becomes an `EngineError`. Harmless
today only because the engine exclusively sees scripted traffic; fatal the moment
real or replayed frames reach it. Same file: the engine transmits all fragments
immediately and unsolicited (no poll gating), so despite `Runner`'s "future radio
thread" comment it cannot be pointed at the physical radio as-is.

### 7. `firmware_reply_queued` misreads mismatch diagnostics as "queued"

`crates/picto-relay-join/src/main.rs` (`firmware_reply_queued`): the fallback path
takes any nonzero fragment-number nibble and tests `& FIRMWARE_DIAGNOSTIC_QUEUED`.
The mismatch/arm-failure codes `0x0b`, `0x0c`, `0x05`, `0x09`, `0x0f` all have bit
0 set and are not filtered here (unlike `FirmwareTransportReport::observe`, which
filters them first). During an active message this inflates `queued_replies` and
sets `awaiting_ack`, mis-pairing the next ack. Stats-level impact, but it skews
exactly the timing numbers used to reason about the P1 bug.

### 8. Small wire-shape deltas vs. the real client

- Deauthentication: real client leaves with duration `0x00a2` and the PM bit set;
  `leave_room` sends `build_management_frame(12, …)` → duration 0, PM clear. The
  host demonstrably accepts it, but everywhere else the project mimics captured
  shapes byte-for-byte — this is the one management frame that doesn't.
- The clean baseline contains 26 client **CF-Ack (no data), subtype 5** frames
  interleaved with the replies (durations 240/1030). The docs' transport table
  only mentions data subtype 1. They currently decode as empty client replies,
  which is fine, but the shape is unrecorded.
- After `DeliveryTimedOut`, the live backend neither disarms nor resets the
  firmware transaction; the host has received a partial fragment set that is
  abandoned without any completion/abort control record. Re-arming later resets
  `picto_message_index` (arm of template 9 clears it), so the *next* message is
  fine, but the host-side partial transfer's fate is untested.

### 9. Documentation numbers to refresh

- `pictochat-protocol.md` cites the 12-second hold ("1,405 polls / 13 misses",
  ~0.9 %) as the timing evidence; the 360-second canonical outbound session shows
  1.44 % sustained round failure — the number that actually governs transaction
  reliability (finding 1) deserves to be in the doc.
- The beacon `game_id` for PictoChat is observed `0x00000000` in all captures;
  the docs keep it fully opaque, which is fine, but noting the observed value
  would help interop debugging (association SSID = all zeros + stream code).

---

## Method notes

The analysis scripts that produced every number above live in
[`evaluation/scripts/`](scripts/) (standalone Python 3, no external
dependencies):

| Script | What it does |
|---|---|
| `picto.py` | Shared library: parses pcap records, radiotap (TSFT/flags/rate/antenna, FCS handling), 802.11 headers, and classifies the three Nintendo flows by multicast placement |
| `analyze.py` | Per-capture frame inventory plus envelope-length-convention validation (host, client, and padded-final rules) |
| `timing.py` | cmd→reply→ack pairing, latency distributions, `client_time`/mask census, `command_count` correlation tests, failed-round follow-up behavior |
| `ordering.py` | Application-level conversation dumps: identity-exchange ordering (`identity` mode) and transfer fragment timelines with failed acks (`transfer` mode) |
| `raw.py` | Raw byte + radiotap dumps that exposed the arm-frame/TX-loopback capture artifacts |
| `tail.py` | Outbound transaction tail, padded-final verification, failure-rate census, real-client MAC field census, beacon field extraction, management-exchange dump |
| `templates.py` | Dumps the real client's application replies for diffing against the hard-coded Rust templates |

Run them from `evaluation/scripts/` with a capture filename from
`captures/blueberry/`, e.g. `python3 timing.py 01-two-ds-baseline.pcap` or
`python3 ordering.py 1787193673345-real-ds-clean-join-baseline.pcap identity`.

Timing medians (cmd→reply ≈ 238 µs including 6-byte-cmd airtime at 2 Mbps;
cmd→ack ≈ 1.24 ms ≈ `client_time` 998 µs + airtime) are consistent with the
SIFS-boundary reply model the docs describe.
