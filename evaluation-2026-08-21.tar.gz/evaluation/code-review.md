# Code review: cleanup & improvement suggestions

Date: 2026-08-21. Scope: all seven workspace crates. This is a **code-quality**
pass (dead code, duplication, structure, lint/CI health) — distinct from
[`findings.md`](findings.md), which covers protocol correctness against the
captures. Nothing here has been changed; these are recorded suggestions only.

Signals used: `cargo clippy --workspace --all-targets --all-features --locked`,
`cargo test --workspace` (all green, 95 tests), and reference-counting each
suspect symbol across the tree.

## Headline

The library code is clean and well-factored — the codec is a properly
panic-free parser (every `unwrap`/`expect` is test-only), errors are typed, and
the deterministic-engine split is a nice idea. The issues are concentrated in
two places: **a documented check that no longer passes**, and **a pile of dead
code that a structural trick actively hides from the compiler**.

---

## A. The documented verify command fails today

`README.md` and each crate README advertise:

```sh
cargo clippy --workspace --all-targets --all-features --locked -- -D warnings
```

That command **fails right now** — clippy reports four warnings, all in
`picto-relay-repl`:

| Warning | Location |
|---|---|
| `constant NATIVE_DRAWING_HEIGHT is never used` | `repl/src/main.rs:18` |
| `function text_line_capacity is never used` | `repl/src/main.rs:436` |
| `function text_capacity is never used` | `repl/src/main.rs:442` |
| `manual !Range::contains implementation` | `repl/src/main.rs:608` |

The workspace lint table (`Cargo.toml`) sets clippy to `warn`, not `deny`, so a
plain `cargo clippy` exits 0 and the regression is invisible unless someone
appends `-D warnings`. There is also **no CI** (`.github/workflows/` does not
exist), so nothing enforces the README's own commands.

**Suggestions:**
1. Delete the three dead REPL items (§B) and apply the `Range::contains` fix.
2. Add a CI workflow that runs exactly the two README commands, so the claim
   stays true.
3. Consider promoting `workspace.lints.clippy` to `deny` for `all` — but only
   *after* the tree is clean, or every build breaks.

---

## B. Dead code (safe to delete)

Each item below has **zero non-definition references** in the tree (test uses
noted explicitly). Line numbers are current.

### Confirmed unused public API in `picto-relay-codec`
- **`build_data_frame_to_ds`** (`frame.rs:291`) — `pub`, re-exported from
  `lib.rs`, never called. The To-DS client frame is built by
  `build_client_reply_frame` instead. ~23 lines + the export.
- **`FrameControl::more_fragments`** (`frame.rs:79`) — never read. (Its siblings
  `to_ds`/`from_ds`/`retry` are all used.)
- **`MacFrame::fcs`** (`frame.rs:255`) — the FCS is detected and its bytes are
  retained, but this accessor is never called. Either wire it into the listener's
  output or drop it.
- **`encode_one_band_message`** (`message.rs:82`) — since the general
  `encode_message` was added and `join` switched to it, this is now only a
  test-only validation wrapper. Fold the "exactly one band" check into the
  callers/tests, or keep it but mark it clearly as a convenience shim.

### Confirmed unused in `picto-relay-engine`
- **`Engine::client_mac`** (`lib.rs:190`) — `pub`, never called anywhere.

### Dead in `picto-relay-repl`
- The three clippy-flagged items from §A (`NATIVE_DRAWING_HEIGHT`,
  `text_line_capacity`, `text_capacity`).

---

## C. Whole subsystems that never run in production

These compile and are unit-tested, but nothing in a shipped binary ever reaches
them. That is more than dead code — it is *maintained* dead weight that looks
load-bearing.

### C1. The engine's room-tracking is write-only
`RoomState` / `RoomLifecycle` / `Engine::observe_management` (`lib.rs:105`,
`:308`) populate a rich room model — host, slot map, stream code, capacities —
but **no production consumer reads `engine.room()`**; the only readers are the
engine's own tests. Worse, the default `Broker` never feeds beacons or
management frames to the engine at all (its loopback only re-injects the
client's own transmissions), so `observe_management` is never even called
outside tests. ~90 lines of state machine that is currently a no-op in the
running server.

### C2. The engine's retry/timeout path is unreachable
`Engine::handle_tick` (`lib.rs:426`), `EngineEffect::ScheduleWakeup`
(`lib.rs:79`), and `RunnerOutput.wakeups` form a retry-then-timeout mechanism —
but nothing in production ever drives it:
- No code sends `EngineEvent::Tick` outside tests (the broker has no timer).
- `Broker::route` consumes `output.notifications` and **silently drops
  `output.wakeups`**, so even the scheduling half is ignored.

So the retry, the `DeliveryTimedOut` notification, and `mark_retry` never fire in
the default backend. Either wire a timer into the broker (a `tokio::time`
interval feeding `EngineEvent::Tick` and honoring `wakeups`) or remove the
machinery. This also intersects finding #2: the ack-correlation the retry path
depends on is falsified by the captures, so wiring it up as-is would misbehave —
fix the correlation first if you keep it.

---

## D. Structural / architectural

### D1. Two parallel protocol implementations
There are effectively **two independent PictoChat clients** in the tree:

| Path | Backend | Used by |
|---|---|---|
| `Engine` (picto-relay-engine) | `Broker` + `ScriptedRadio` loopback | default `--backend scripted` |
| `run_live_backend` / `maintain_live_backend` / `initialization_reply` (picto-relay-join) | `LiveBroker` + real radio | `--backend ar9271` |

The two share only the codec — they duplicate session logic, reassembly,
duplicate-suppression, and delivery detection with *different* rules. The
"deterministic engine" reads as the protocol core, but the real device never
touches it; it is a loopback simulator whose delivery model is the
capture-falsified one from `findings.md`. Suggestion: either (a) rename/document
the Engine explicitly as a simulation harness, or (b) invest in making it the
single source of truth and have the live backend drive *it* (feeding real host
frames in, taking transmit effects out) instead of reimplementing the protocol.
Option (b) would also give the hardware path the engine's test coverage.

### D2. `#[path = "main.rs"] mod implementation` hides a 2,700-line binary in the library
`picto-relay-join/src/lib.rs` includes the *entire* standalone probe
(`main.rs`) as a module and slaps a blanket `#[expect(dead_code)]` on it, then
re-exports four items. Consequences:
- **Dead-code detection is disabled for the whole file.** Any unused helper in
  those 2,700 lines is permanently invisible to the compiler — the opposite of
  what you want in the largest source file in the repo.
- **The server binary links the whole CLI probe** — clap parsing,
  `prepare_radio_interfaces`, the SSH-peer/route guards, `run_join`,
  `maintain_membership`, the timing-report `println!`s — despite using only
  `run_live_backend` + 3 types.

Suggestion: move the genuinely reusable worker (live backend, config, events,
templates, codec glue) into `lib.rs` as real modules, and keep `main.rs` as a
thin bin that depends on the lib. Dead code becomes visible again and the server
stops dragging in the probe UI.

### D3. `experimental_profile` is a broken legacy path
The software-reply identity exchange (`--experimental-profile`,
`MembershipConfig.experimental_profile`, the `initialization_reply` branch in
`maintain_membership`) exists only in the standalone probe and carries the
session-response deadlock documented in `findings.md` §4 (it never emits the
opening `c34` session response, so a real host loops forever). It has never
worked against real hardware. Either delete it or clearly mark it as a
non-functional diagnostic so no one mistakes it for a software fallback.

### D4. Small duplication
- **`station_id`** (`engine/src/lib.rs:462`, `pub`) and **`station_id_from_mac`**
  (`join/src/main.rs:2326`, private) are byte-identical. Have `join` use the
  codec/engine one.
- **`decode_hex`** is copy-pasted in five files (`listener/decode.rs`,
  `join/main.rs` tests, `engine/lib.rs` tests, and both `codec/tests/*.rs`).
  Promote it to a shared `dev-dependency` test-util or a `pub` codec helper.

---

## E. Minor polish

- **`arm_live_message` vs `firmware_reply_templates` sequence bases** differ
  (`+ 0x100` vs `.saturating_add(2)`) for the same template arming. Not a bug,
  but the magic offsets deserve named constants and a comment on why the message
  path starts at `0x100`.
- **`firmware_reply_queued`** (finding #7 in `findings.md`) doesn't filter the
  mismatch/arm-failure diagnostic codes before testing the QUEUED bit, unlike
  `FirmwareTransportReport::observe`. Worth factoring the "decode a diagnostic
  nibble" logic into one shared function so the two callers can't drift.
- Several crate READMEs restate the same verify block; once CI runs it, the
  per-crate copies can point at the root instead of duplicating.

---

## Suggested order of work

1. **Make the verify command true** — delete the REPL dead items, fix the lint,
   add a CI workflow (§A, §B-repl). Cheap, unblocks everything else.
2. **Delete the confirmed-dead public API** (§B) — pure subtraction, no behavior
   change.
3. **Decide the engine's fate** (§C, §D1) — the biggest lever. Either wire the
   retry/room paths into the broker and make the engine the real core, or demote
   it to a clearly-labeled simulator and stop maintaining the unused halves.
4. **Restructure the join crate** (§D2) so dead code is visible and the server
   binary slims down.
5. **Retire `experimental_profile`** (§D3) and de-duplicate the helpers (§D4).
