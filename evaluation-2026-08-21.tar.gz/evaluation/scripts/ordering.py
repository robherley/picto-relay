"""Dump app-level conversation ordering: identity exchange + transfer + retry behavior."""
import sys, collections, struct
from picto import *

CAP = CAPTURES

def app(f):
    if f.kind[0]=="cmd":
        payload = f.body[4:]
    elif f.kind[0]=="reply":
        payload = f.body
    elif f.kind[0]=="ack":
        return None
    if len(payload) < 6: return ("short", payload.hex())
    pid, pseq, dlen, rest = envelope(payload)
    return (pid, pseq, dlen, rest)

def frag(rest, host):
    if len(rest) < 10: return None
    dl, fin = rest[2], rest[3]
    off = struct.unpack_from("<H", rest, 4)[0]
    oid = rest[6:8].hex()
    if host:
        fn, tr = struct.unpack_from("<HH", rest, len(rest)-4)
    else:
        fn = struct.unpack_from("<H", rest, len(rest)-2)[0]; tr = None
    return dl, fin, off, oid, fn, tr

def conversation(path, client=None, around_transfer=False):
    frames = [f for f in read_pcap(CAP+path) if f.kind[0] in ("cmd","reply","ack")]
    t0 = frames[0].ts if frames else 0
    lines = []
    for f in frames:
        k = f.kind[0]
        ts_ms = (f.ts - t0)/1e6
        if k == "ack":
            cc, fm = struct.unpack_from("<HH", f.body, 0) if len(f.body)>=4 else (0,0)
            if fm:
                lines.append((ts_ms, f"ACK  cc={cc} FAILED={fm:04x}"))
            continue
        a = app(f)
        if a is None: continue
        if a[0] == "short":
            if k == "reply":
                lines.append((ts_ms, f"RPLY {mac(f.a2)[-8:]} seq={f.seq} retry={int(f.retry)} short:{a[1]}"))
            continue
        pid, pseq, dlen, rest = a
        fam = (pid >> 8) & 0x0f
        desc = f"{'CMD ' if k=='cmd' else 'RPLY'} {mac(f.a2)[-8:]} seq={f.seq:4} r={int(f.retry)} pid={pid:04x} aseq={pseq} dlen={dlen}"
        if fam == 0x0e:
            fr = frag(rest, k=='cmd')
            if fr:
                dl, fin, off, oid, fn, tr = fr
                if dl == 84:
                    desc += f" [identity sub={rest[9] if len(rest)>9 else '?'}]"
                else:
                    desc += f" [frag dl={dl} fin={fin} off={off} id={oid} fn={fn}]"
        lines.append((ts_ms, desc))
    return lines

if __name__ == "__main__":
    path = sys.argv[1]
    mode = sys.argv[2] if len(sys.argv) > 2 else "identity"
    lines = conversation(path)
    if mode == "identity":
        # print everything except idle c34 repeats: compress runs
        prev = None; run = 0
        for ts, d in lines:
            key = d.split("pid=")[-1][:9] if "pid=" in d else d
            if "pid=1c34" in d or "pid=9c34" in d:
                if prev == "c34": run += 1; continue
                if run: pass
                prev = "c34"; run = 1
                print(f"{ts:9.2f} {d}   [c34 roster, run starts]")
            else:
                if prev == "c34" and run > 1:
                    print(f"          ... {run-1} more c34 roster cmds")
                prev = None; run = 0
                print(f"{ts:9.2f} {d}")
    else:
        # transfer mode: show fragment lines and failures only, plus 2 lines context
        for ts, d in lines:
            if "[frag" in d or "FAILED" in d or "d0a" in d.lower():
                print(f"{ts:9.2f} {d}")
