"""Overview stats + envelope-convention checks across the key captures."""
import sys, collections, struct
from picto import *

CAP = CAPTURES

def envelope_check(frames):
    """Validate host/client declared-length conventions the codec enforces."""
    viol = collections.Counter()
    examples = collections.defaultdict(list)
    for f in frames:
        kind = f.kind[0]
        if kind == "cmd":
            if len(f.body) < 4: viol["cmd_short"] += 1; continue
            payload = f.body[4:]
            if len(payload) < 6: continue  # idle
            env = envelope(payload)
            pid, pseq, dlen, rest = env
            halfwords = (pid & 0xff) * 2
            if dlen != len(rest):
                fam = (pid >> 8) & 0x0f
                padded_ok = fam == 0x0e and halfwords == len(rest) and dlen <= len(rest)
                tag = f"host dlen!=len pid={pid:04x} dlen={dlen} len={len(rest)}"
                if padded_ok: tag += " [padded-exception]"
                viol[tag] += 1
            elif halfwords != dlen and halfwords != len(rest):
                viol[f"host pid-len mismatch pid={pid:04x} dlen={dlen}"] += 1
        elif kind == "reply":
            payload = f.body
            if len(payload) < 6: continue
            pid, pseq, dlen, rest = envelope(payload)
            if dlen != len(rest) + 2:
                viol[f"client dlen!=len+2 pid={pid:04x} dlen={dlen} len={len(rest)}"] += 1
            elif (pid & 0xff) * 2 != dlen:
                viol[f"client pid-len mismatch pid={pid:04x} dlen={dlen}"] += 1
        elif kind == "ack":
            if len(f.body) != 4:
                viol[f"ack body len {len(f.body)}"] += 1
    return viol

def overview(path):
    frames = read_pcap(path)
    kinds = collections.Counter(f.kind for f in frames)
    print(f"== {path.split('/')[-1]}: {len(frames)} frames")
    for k, c in kinds.most_common(12):
        print(f"   {k}: {c}")
    v = envelope_check(frames)
    if v:
        print("   envelope violations:")
        for tag, c in v.most_common(15):
            print(f"     {c:6} {tag}")
    else:
        print("   envelope conventions: all clean")
    return frames

if __name__ == "__main__":
    for name in sys.argv[1:]:
        overview(CAP + name)
