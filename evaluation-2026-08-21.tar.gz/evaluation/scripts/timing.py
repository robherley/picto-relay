"""cmd->reply->ack ordering, timing, ack command_count semantics, retry behavior."""
import sys, collections, struct
from picto import *

CAP = CAPTURES

def run(path, host=None, verbose=False):
    frames = [f for f in read_pcap(CAP+path) if f.kind[0] in ("cmd","reply","ack")]
    print(f"== {path}: {len(frames)} nintendo data frames")
    # identify host
    hosts = collections.Counter(mac(f.a2) for f in frames if f.kind[0]=="cmd")
    print("   cmd sources:", hosts.most_common(3))

    # 1. client_time distribution
    ct = collections.Counter()
    for f in frames:
        if f.kind[0]=="cmd" and len(f.body)>=4:
            t, m = struct.unpack_from("<HH", f.body, 0)
            ct[(t,m)] += 1
    print("   (client_time, mask):", ct.most_common(6))

    # 2. cmd -> reply delta (pcap ts) for targeted cmds; and reply -> ack delta
    deltas_cr, deltas_ca, deltas_ra = [], [], []
    last_cmd = None; last_reply = None
    ack_after_targeted = collections.Counter()
    # track: for each targeted cmd round, was a reply seen before the ack, and what did ack say
    round_state = None  # (cmd_frame, reply_seen)
    rounds = []
    for f in frames:
        if f.kind[0]=="cmd":
            if len(f.body)>=4:
                t, m = struct.unpack_from("<HH", f.body, 0)
                if round_state is not None:
                    rounds.append(round_state + (None,))
                round_state = (f, m, False) if m else None
            last_cmd = f
        elif f.kind[0]=="reply":
            if last_cmd is not None:
                deltas_cr.append((f.ts - last_cmd.ts)//1000)
            if round_state is not None:
                round_state = (round_state[0], round_state[1], True)
            last_reply = f
        elif f.kind[0]=="ack":
            if len(f.body)>=4:
                cc, fm = struct.unpack_from("<HH", f.body, 0)
                if last_cmd is not None:
                    deltas_ca.append((f.ts-last_cmd.ts)//1000)
                if round_state is not None:
                    rounds.append(round_state + ((cc, fm, f),))
                    round_state = None
    import statistics as st
    def s(v):
        return f"n={len(v)} min={min(v)} med={int(st.median(v))} max={max(v)}" if v else "none"
    print("   cmd->reply µs:", s(deltas_cr))
    print("   cmd->ack µs:", s(deltas_ca))

    # 3. ack command_count vs cmd MAC seq / reply MAC seq
    match_cmdseq = match_replyseq = match_prev_cc = 0
    cc_deltas = collections.Counter()
    prev_cc = None
    examined = 0
    for (cmd, m, reply_seen, ackinfo) in rounds:
        if ackinfo is None: continue
        cc, fm, ackf = ackinfo
        examined += 1
        if cmd.seq is not None and cc == cmd.seq: match_cmdseq += 1
        if prev_cc is not None:
            cc_deltas[(cc - prev_cc) & 0xffff] += 1
        prev_cc = cc
    print(f"   rounds with ack: {examined}; ack.cc == cmd.macseq: {match_cmdseq}")
    print("   command_count deltas:", cc_deltas.most_common(6))

    # 4. failed rounds: what happens after a failed mask?
    fails = 0; fail_follow = collections.Counter()
    prev_app = None
    seqinfo = []
    for i,(cmd, m, reply_seen, ackinfo) in enumerate(rounds):
        if ackinfo is None: continue
        cc, fm, ackf = ackinfo
        if fm:
            fails += 1
            # what's the next targeted cmd payload family vs this one?
            this_env = envelope(cmd.body[4:]) if len(cmd.body)>=10 else None
            nxt = next((r for r in rounds[i+1:] if r[1]), None)
            if nxt:
                nxt_env = envelope(nxt[0].body[4:]) if len(nxt[0].body)>=10 else None
                a = f"{this_env[0]:04x}" if this_env else "idle"
                b = f"{nxt_env[0]:04x}" if nxt_env else "idle"
                fail_follow[(a, b, "same-bytes" if (this_env and nxt_env and cmd.body==nxt[0].body) else "diff")] += 1
    print(f"   failed rounds: {fails}; next targeted cmd after failure:", fail_follow.most_common(8))

if __name__ == "__main__":
    for p in sys.argv[1:]:
        run(p)
