"""Parse PictoChat pcaps (radiotap + 802.11) and run protocol checks."""
import struct, sys, os, collections

HOST_TO_CLIENT = bytes.fromhex("0309bf000000")
CLIENT_ACK     = bytes.fromhex("0309bf000003")
CLIENT_REPLY   = bytes.fromhex("0309bf000010")

class Frame:
    __slots__ = ("ts","tsft","rt_flags","rate","antenna","fc","dur","a1","a2","a3","seq","frag","body","retry","kind","raw80211")

def parse_radiotap(data):
    if len(data) < 8: return None
    ver, pad, rlen = data[0], data[1], struct.unpack_from("<H", data, 2)[0]
    if ver != 0 or rlen > len(data): return None
    presents = []
    off = 4
    while True:
        if off+4 > rlen: return None
        p = struct.unpack_from("<I", data, off)[0]
        presents.append(p); off += 4
        if not (p & 0x80000000): break
    # walk fields of first present word only (vendor ns etc. ignored for extras)
    fields = {}
    pos = off
    def align(n):
        nonlocal pos
        pos = (pos + (n-1)) & ~(n-1)
    p = presents[0]
    sizes = {0:(8,8),1:(1,1),2:(1,1),3:(2,4),4:(2,2),5:(1,1),6:(1,1),7:(2,2),8:(2,2),9:(2,2),10:(1,1),11:(1,1),12:(1,1),13:(1,1),14:(2,2),15:(2,2),16:(1,1),17:(1,1),18:(8,4),19:(1,3),20:(2,8),21:(2,12)}
    for bit in range(29):
        if not (p & (1<<bit)): continue
        if bit not in sizes: break
        al, sz = sizes[bit]
        align(al)
        if pos+sz > rlen: break
        if bit == 0: fields["tsft"] = struct.unpack_from("<Q", data, pos)[0]
        elif bit == 1: fields["flags"] = data[pos]
        elif bit == 2: fields["rate"] = data[pos]
        elif bit == 5: fields["rssi"] = struct.unpack_from("<b", data, pos)[0]
        elif bit == 11: fields["antenna"] = data[pos]
        pos += sz
    return rlen, fields

def parse_frame(ts, data):
    rt = parse_radiotap(data)
    if rt is None: return None
    rlen, fields = rt
    dot11 = data[rlen:]
    flags = fields.get("flags", 0)
    if flags & 0x10 and len(dot11) >= 4:  # FCS present
        dot11 = dot11[:-4]
    if flags & 0x40:  # bad FCS
        return None
    if len(dot11) < 10: return None
    f = Frame()
    f.ts = ts
    f.tsft = fields.get("tsft")
    f.rt_flags = flags
    f.rate = fields.get("rate")
    f.antenna = fields.get("antenna")
    f.fc = struct.unpack_from("<H", dot11, 0)[0]
    f.dur = struct.unpack_from("<H", dot11, 2)[0]
    f.retry = bool(f.fc & (1<<11))
    ftype = (f.fc >> 2) & 3
    subtype = (f.fc >> 4) & 0xf
    f.a1 = dot11[4:10]
    f.a2 = dot11[10:16] if len(dot11) >= 16 else None
    f.a3 = dot11[16:22] if len(dot11) >= 22 else None
    f.seq = f.frag = None
    f.raw80211 = dot11
    hdr = 24
    if ftype in (0,2) and len(dot11) >= 24:
        sc = struct.unpack_from("<H", dot11, 22)[0]
        f.seq, f.frag = sc >> 4, sc & 0xf
    if ftype == 2 and subtype & 8: hdr += 2
    f.body = dot11[hdr:] if len(dot11) >= hdr else b""
    if ftype == 0:
        f.kind = ("mgmt", subtype)
    elif ftype == 2:
        if f.a1 == HOST_TO_CLIENT: f.kind = ("cmd", subtype)
        elif f.a1 == CLIENT_ACK: f.kind = ("ack", subtype)
        elif f.a3 == CLIENT_REPLY or f.a1 == CLIENT_REPLY: f.kind = ("reply", subtype)
        else: f.kind = ("data", subtype)
    else:
        f.kind = ("ctl" if ftype==1 else "other", subtype)
    return f

def read_pcap(path):
    frames = []
    with open(path, "rb") as fh:
        gh = fh.read(24)
        if len(gh) < 24: return frames
        magic = struct.unpack_from("<I", gh, 0)[0]
        if magic == 0xa1b2c3d4: endian, scale = "<", 1000
        elif magic == 0xa1b23c4d: endian, scale = "<", 1
        elif magic == 0xd4c3b2a1: endian, scale = ">", 1000
        else: return frames
        linktype = struct.unpack(endian+"I", gh[20:24])[0]
        while True:
            rh = fh.read(16)
            if len(rh) < 16: break
            ts_s, ts_f, incl, orig = struct.unpack(endian+"IIII", rh)
            data = fh.read(incl)
            if len(data) < incl: break
            ts_ns = ts_s * 1_000_000_000 + ts_f * scale
            fr = parse_frame(ts_ns, data)
            if fr is not None: frames.append(fr)
    return frames

def mac(b): return ":".join(f"{x:02x}" for x in b) if b else "?"

def envelope(payload):
    if len(payload) < 6: return None
    pid, pseq, dlen = struct.unpack_from("<HHH", payload, 0)
    return pid, pseq, dlen, payload[6:]

import pathlib
CAPTURES = str(pathlib.Path(__file__).resolve().parents[2] / "captures" / "blueberry") + "/"
