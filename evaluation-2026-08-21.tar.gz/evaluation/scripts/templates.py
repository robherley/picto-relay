"""Dump real client's app replies (clean baseline) to compare with Rust templates."""
import struct
from picto import *
CAP = CAPTURES
f2 = read_pcap(CAP + "1787193673345-real-ds-clean-join-baseline.pcap")
t0 = f2[0].ts
for f in f2:
    if f.kind[0] != "reply" or len(f.body) < 6: continue
    print(f"{(f.ts-t0)/1e6:9.2f} len={len(f.body):3} {f.body.hex()}")
