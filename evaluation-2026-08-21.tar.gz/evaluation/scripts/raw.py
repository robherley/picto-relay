"""Dump raw bytes + radiotap details for chosen reply frames in outbound capture."""
import struct, collections
from picto import *

CAP = CAPTURES
path = CAPTURES + "1787275056402-virtual-client-outbound-dot-padded-final.pcap"

frames = read_pcap(path)
t0 = frames[0].ts
count = 0
for f in frames:
    if f.kind[0] != "reply": continue
    if f.seq in (257, 122, 123, 121, 271, 270) and len(f.body) > 6:
        pid = struct.unpack_from("<H", f.body, 0)[0] if len(f.body)>=2 else 0
        count += 1
        print(f"ts={(f.ts-t0)/1e6:9.2f}ms seq={f.seq} pid={pid:04x} rtflags={f.rt_flags:02x} "
              f"rate={f.rate} ant={f.antenna} rssi=? dur={f.dur} bodylen={len(f.body)}")
        print("   tail24:", f.body[-24:].hex())
        print("   head16:", f.body[:16].hex())
        if count > 14: break

# also: count envelope-length conventions among *poll-cadence* replies (seq 100-200)
viol = collections.Counter()
for f in frames:
    if f.kind[0] != "reply" or len(f.body) < 6: continue
    pid, pseq, dlen = struct.unpack_from("<HHH", f.body, 0)
    rest = len(f.body) - 6
    tag = "ok" if dlen == rest + 2 else ("wire==dlen(+2 extra)" if dlen == rest else f"other({dlen} vs {rest})")
    viol[(f"{pid:04x}", tag)] += 1
print(viol.most_common(20))
