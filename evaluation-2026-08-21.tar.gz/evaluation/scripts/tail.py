"""Transaction tail + padded final + real-client MAC details + beacon fields."""
import struct, collections
from picto import *

CAP = CAPTURES

# 1. outbound capture: transaction window details
path = CAP + "1787275056402-virtual-client-outbound-dot-padded-final.pcap"
frames = read_pcap(path)
t0 = frames[0].ts
print("=== outbound transaction tail (4980ms-5100ms) + failed acks in window ===")
for f in frames:
    ms = (f.ts-t0)/1e6
    if not (4980 <= ms <= 5120): continue
    if f.kind[0] == "cmd":
        pl = f.body[4:]
        if len(pl) >= 6:
            pid, ps, dl = struct.unpack_from("<HHH", pl, 0)
            if (pid>>8)&0x0f == 0x0e:
                rest = pl[6:]
                off = struct.unpack_from("<H", rest, 4)[0]
                fn, tr = struct.unpack_from("<HH", rest, len(rest)-4)
                print(f"{ms:8.2f} CMD pid={pid:04x} dlen={dl} wire={len(rest)} dl={rest[2]} fin={rest[3]} off={off} fn={fn} tr={tr}")
            elif pid in (0x1d0a, 0x9d0a):
                print(f"{ms:8.2f} CMD pid={pid:04x} d0a payload={pl[6:].hex()}")
    elif f.kind[0] == "ack" and len(f.body) >= 4:
        cc, fm = struct.unpack_from("<HH", f.body, 0)
        if fm:
            print(f"{ms:8.2f} ACK FAILED={fm:04x} cc={cc}")

print()
print("=== failed acks across whole outbound capture (bucketed by second) ===")
fails = [ (f.ts-t0)/1e9 for f in frames if f.kind[0]=="ack" and len(f.body)>=4 and struct.unpack_from("<HH", f.body,0)[1] ]
total_acks = sum(1 for f in frames if f.kind[0]=="ack")
print(f"total acks {total_acks}, failed {len(fails)}; failure seconds: {[round(x,1) for x in fails]}")

# 2. real client reply MAC details from clean baseline
print()
print("=== real DS client reply MAC header details (clean baseline) ===")
path2 = CAP + "1787193673345-real-ds-clean-join-baseline.pcap"
f2 = read_pcap(path2)
subtype = collections.Counter(); durs = collections.Counter(); pm = collections.Counter()
rates = collections.Counter()
for f in f2:
    if f.kind[0] == "reply":
        subtype[f.kind[1]] += 1
        durs[(len(f.body), f.dur)] += 1
        pm[bool(f.fc & (1<<12))] += 1
        rates[f.rate] += 1
print("subtypes:", subtype.most_common())
print("pwr-mgmt flag:", pm.most_common())
print("rates(x500kbps):", rates.most_common())
print("(bodylen, duration):", sorted(durs.items())[:12])
# host cmd durations
cd = collections.Counter((len(f.body), f.dur) for f in f2 if f.kind[0]=="cmd")
print("cmd (bodylen, duration):", sorted(cd.items())[:8])
ad = collections.Counter((len(f.body), f.dur) for f in f2 if f.kind[0]=="ack")
print("ack (bodylen, duration):", sorted(ad.items())[:8])

# 3. beacon vendor element from clean baseline
print()
print("=== beacon fields (clean baseline) ===")
seen = set()
for f in f2:
    if f.kind != ("mgmt", 8): continue
    body = f.body
    if len(body) < 12: continue
    interval, cap = struct.unpack_from("<HH", body, 8)
    off = 12
    while off + 2 <= len(body):
        eid, ln = body[off], body[off+1]
        data = body[off+2:off+2+ln]
        off += 2 + ln
        if eid == 0xdd and data[:4] == bytes.fromhex("0009bf00"):
            step, vs = struct.unpack_from("<HH", data, 4)
            fixed, gid = struct.unpack_from("<II", data, 8)
            sc = struct.unpack_from("<H", data, 16)[0]
            cl, bt = data[18], data[19]
            cds, rds = struct.unpack_from("<HH", data, 20)
            key = (interval, step, vs, fixed, gid, cl, bt, cds, rds, data[24:32].hex()[8:])
            if key not in seen and len(seen) < 6:
                seen.add(key)
                print(f"interval={interval} step={step} vsync={vs} fixed=0x{fixed:08x} game_id=0x{gid:08x} stream=0x{sc:04x} clen={cl} btype={bt} cmd_cap=0x{cds:04x} rep_cap=0x{rds:04x} custom={data[24:24+cl].hex()}")

# 4. mgmt frames: auth/assoc/deauth details
print()
print("=== management exchange (clean baseline) ===")
for f in f2:
    k = f.kind
    if k[0] != "mgmt" or k[1] == 8: continue
    ms = (f.ts - f2[0].ts)/1e6
    print(f"{ms:9.2f} subtype={k[1]:2} a1={mac(f.a1)} a2={mac(f.a2)} dur=0x{f.dur:04x} pm={bool(f.fc&(1<<12))} body={f.body[:44].hex()}")
